#ifndef SYSTEM_H
#define SYSTEM_H

#include <Arduino.h>
#include "device_config.h"

uint64_t millisecondsRunned(); // Время в милисекундах
uint64_t secondsRunned(); // Время в секундах
uint64_t minutesRunned(); // Время в минутах

void rebootLoop(bool trigger = false); // reboot

#endif