#include "mqtt_onmessage.h"

void analyzeMqttMessage(String topic, String msg)
{
  Serial.println("Get message: \"" + topic + "\" (" + msg + ")");
  // if (topic == FSReadJsonString("dev_uid") + "/switch/ch1/command")
  // {

  //   channelStates[1] = msg == "ON" ? true : false;
  //   updateChannel(1);
  // }
  // else if (topic == FSReadJsonString("dev_uid") + "/switch/ch2/command")
  // {

  //   channelStates[2] = msg == "ON" ? true : false;
  //   updateChannel(2);
  // }
  // else if (topic == FSReadJsonString("dev_uid") + "/light/ch1/command")
  // {
  //   if (msg == "{\"state\":\"ON\"}")
  //     channelStates[1] = true;
  //   else if (msg == "{\"state\":\"OFF\"}")
  //     channelStates[1] = false;
  //   updateChannel(1);
  // }
  // else if (topic == FSReadJsonString("dev_uid") + "/light/ch2/command")
  // {
  //   if (msg == "{\"state\":\"ON\"}")
  //     channelStates[2] = true;
  //   else if (msg == "{\"state\":\"OFF\"}")
  //     channelStates[2] = false;
  //   updateChannel(2);
  // }
  // else if (topic == FSReadJsonString("dev_uid") + "/button/reboot/command")
  // {
  //   if (msg == "PRESS")
  //   {
  //     Serial.println("reboot mqtt message accepted");
  //     rebootLoop(true);
  //   }
  // }
}