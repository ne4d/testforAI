#ifndef SWITCHES_H
#define SWITCHES_H

#include "../fs/filesystem.h"
#include "../device_config.h"
#include "../mqtt/mqtt_publish.h"

void initChannels();
void updateChannel(uint8_t ch);

#endif