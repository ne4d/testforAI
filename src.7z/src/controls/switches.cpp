#include "switches.h"

void initChannels()
{
  // // Выделение памяти для массивов
  // channelStates = new bool[channel_count + 1]();
  // channelPins = new uint8_t[channel_count + 1]();

  // // назначение пинов вводов
  // channelPins[1] = 41;
  // channelPins[2] = 40;

  // // чтение состояний на момент запуск7а
  // for (uint8_t i = 1; i <= channel_count; i++)
  // {
  //   pinMode(channelPins[i], OUTPUT);
  //   digitalWrite(channelPins[i], LOW); // отключение при перезагрузке
  //   String ch_val = "channel" + String(i) + "State";
  //   channelStates[i] = FSReadJsonBool(ch_val.c_str());
  // }
}

void updateChannel(uint8_t ch) {
  // digitalWrite(channelPins[ch], channelStates[ch]);
  // String ch_val = "channel" + String(ch) + "State";
  // FSWriteJsonBool(ch_val.c_str(), channelStates[ch]);
  // Serial.println("Channel " + String(ch) + " state: " + (channelStates[ch] ? "ON" : "OFF"));
  // publishChannelState(ch);
}