#ifndef MQTT_PUBLISH_H
#define MQTT_PUBLISH_H

#include <Arduino.h>
#include "config.h"
#include "mqtt.h"
#include "../device_config.h"
#include "../web/pages.h"

void publishMQTTConfig();

#endif